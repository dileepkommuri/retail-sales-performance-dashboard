"""Run PM4Py directly on the complete EHR event-log CSV and save execution evidence.

Example (PowerShell):
  python Dileep_PM4Py_Process_Discovery_Execution.py "C:\\data\\ehr_event_logs_10M.csv"

The script prints observed results. It does not substitute expected/reference
values for a real discovery run. Column names can be supplied when they differ.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
import pm4py


EXPECTED = {
    "events": 10_000_000,
    "cases": 1_562_554,
    "activities": 6,
    "transitions": 8,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path, help="Path to the 10M-event CSV or a ZIP containing one CSV")
    parser.add_argument("--case-column", default="visit_id")
    parser.add_argument("--activity-column", default="activity")
    parser.add_argument("--timestamp-column", default="timestamp")
    parser.add_argument("--output", type=Path, default=Path("pm4py_execution_output.txt"))
    parser.add_argument("--encoding", default="utf-8")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.csv.is_file():
        raise FileNotFoundError(f"Event-log CSV not found: {args.csv}")

    print("PM4Py Directly-Follows Graph (DFG) Execution")
    print(f"Input: {args.csv.resolve()}")
    print("Reading only the case, activity, and timestamp columns to reduce memory use.", flush=True)
    available_columns = pd.read_csv(
        args.csv, encoding=args.encoding, compression="infer", nrows=0
    ).columns.tolist()
    required = [args.case_column, args.activity_column, args.timestamp_column]
    missing = [column for column in required if column not in available_columns]
    if missing:
        raise ValueError(
            f"Missing columns {missing}. Available columns: {available_columns}. "
            "Pass the correct column names with --case-column, --activity-column, "
            "and --timestamp-column."
        )

    log = pd.read_csv(
        args.csv,
        encoding=args.encoding,
        compression="infer",
        usecols=required,
        dtype={args.case_column: "string", args.activity_column: "category"},
    )
    print(f"Loaded {len(log):,} rows. Parsing timestamps and preparing PM4Py columns.", flush=True)
    log[args.timestamp_column] = pd.to_datetime(log[args.timestamp_column], errors="raise")
    log = log.rename(
        columns={
            args.case_column: "case:concept:name",
            args.activity_column: "concept:name",
            args.timestamp_column: "time:timestamp",
        }
    )
    log = pm4py.format_dataframe(
        log,
        case_id="case:concept:name",
        activity_key="concept:name",
        timestamp_key="time:timestamp",
    )

    print("\nExecuting: pm4py.discover_dfg(log)")
    dfg, start_activities, end_activities = pm4py.discover_dfg(log)

    observed = {
        "events": len(log),
        "cases": log["case:concept:name"].nunique(),
        "activities": log["concept:name"].nunique(),
        "transitions": len(dfg),
    }
    lines = [
        "\nObserved dataset counts:",
        f"  Events: {observed['events']:,} (reference: {EXPECTED['events']:,})",
        f"  Cases: {observed['cases']:,} (reference: {EXPECTED['cases']:,})",
        f"  Activities: {observed['activities']:,} (reference: {EXPECTED['activities']:,})",
        f"  DFG transitions: {observed['transitions']:,} (reference: {EXPECTED['transitions']:,})",
        "\nStart activities (frequency):",
    ]
    lines.extend(f"  {activity}: {count:,}" for activity, count in sorted(start_activities.items()))
    lines.append("\nEnd activities (frequency):")
    lines.extend(f"  {activity}: {count:,}" for activity, count in sorted(end_activities.items()))
    lines.append("\nDFG transitions (source -> target: frequency):")
    lines.extend(
        f"  {source} -> {target}: {count:,}"
        for (source, target), count in sorted(dfg.items(), key=lambda item: (str(item[0][0]), str(item[0][1])))
    )
    output = "\n".join(lines)
    print(output)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        "PM4Py execution evidence\n"
        f"Command: python {Path(__file__).name} {args.csv} "
        f"--case-column {args.case_column} --activity-column {args.activity_column} "
        f"--timestamp-column {args.timestamp_column}\n"
        + output
        + "\n",
        encoding="utf-8",
    )
    print(f"\nSaved execution output to: {args.output.resolve()}")

    mismatches = [key for key, value in observed.items() if value != EXPECTED[key]]
    if mismatches:
        print(f"\nNOTICE: Reference count mismatch for {', '.join(mismatches)}; check input and column mapping.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
