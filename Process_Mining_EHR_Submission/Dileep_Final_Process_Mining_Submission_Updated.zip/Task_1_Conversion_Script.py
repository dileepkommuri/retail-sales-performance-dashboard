"""
Dileep — Task 1: Load Event Log into PM4Py
Memory-conscious conversion for a large CSV event log.

Mapping:
    visit_id  -> case identifier
    activity  -> activity
    timestamp -> timestamp
"""

from pathlib import Path
import pandas as pd
import pm4py

CSV_PATH = Path("ehr_event_logs.csv")

# Read only the three columns required by PM4Py.
df = pd.read_csv(
    CSV_PATH,
    usecols=["visit_id", "activity", "timestamp"],
    parse_dates=["timestamp"],
    low_memory=False
)

# Standard PM4Py column names.
df = df.rename(columns={
    "visit_id": "case:concept:name",
    "activity": "concept:name",
    "timestamp": "time:timestamp"
})

# Sort events by case and timestamp.
df = df.sort_values(
    ["case:concept:name", "time:timestamp"],
    kind="mergesort"
).reset_index(drop=True)

# Convert the dataframe to a PM4Py event log.
event_log = pm4py.convert_to_event_log(df)

print("PM4Py conversion successful.")
print("Events:", len(df))
print("Cases:", df["case:concept:name"].nunique())
print("Activities:", df["concept:name"].nunique())
print("PM4Py EventLog type:", type(event_log).__name__)

# Save a PM4Py-compatible Parquet representation for later steps.
# This avoids repeatedly parsing the original 1+ GB CSV.
df.to_parquet("ehr_event_log_pm4py.parquet", index=False)

print("Saved: ehr_event_log_pm4py.parquet")
