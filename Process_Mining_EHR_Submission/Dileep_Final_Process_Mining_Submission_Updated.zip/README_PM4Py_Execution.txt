PM4Py process-discovery execution evidence

Purpose
-------
This script performs a direct PM4Py DFG discovery run on the supplied EHR
event-log CSV or ZIP containing one CSV by calling pm4py.discover_dfg(log). It reports observed counts,
start/end activity frequencies, and every discovered transition frequency.
The reported reference scale is 10,000,000 events, 1,562,554 cases, 6
activities, and 8 transitions. Actual values are only established by running
the script against the source CSV; this package does not invent frequencies.

Run
---
Install Python packages if needed:
  python -m pip install pm4py pandas

Run from the folder containing the script:
  python Dileep_PM4Py_Process_Discovery_Execution.py "C:\path\to\ehr_event_logs_10M.zip"

The source CSV is not embedded because it is a large input dataset. The script
defaults to columns visit_id, activity, and timestamp. If the CSV uses other
names, pass --case-column, --activity-column, and --timestamp-column. The output
is saved to pm4py_execution_output.txt in the current directory by default;
use --output to choose another location.

Memory
------
This full-data PM4Py run holds the input table and formatted event log in memory.
Use a 64-bit Python environment with several GB of available RAM (8 GB or more
is a practical starting point). Do not call this a successful execution until
the generated output file contains the observed start/end and transition counts.

Method limitation
-----------------
Conformance findings in the accompanying project must remain described as
reference-process / trace-variant analysis. This DFG execution is process
discovery evidence; it does not perform formal Petri-net token replay or
alignment-based conformance checking.
